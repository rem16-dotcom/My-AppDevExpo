/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        primary: "#FF8FB1",
        soft: "#FFC2D5",
        light: "#FFF0F5",
        accent: "#F45B91",
        card: "#FFF7FA",
        ink: "#262126",
        muted: "#8C8188",
      },
    },
  },
  plugins: [],
};
