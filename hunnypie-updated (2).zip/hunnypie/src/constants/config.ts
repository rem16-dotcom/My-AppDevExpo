import Constants from "expo-constants";

/**
 * Where the XAMPP backend lives.
 * Normally nothing to change: while you use Expo Go on the same Wi-Fi, the laptop's IP is detected
 * automatically. If it can't connect, put your laptop's IP here, e.g. "http://192.168.1.5/hunnypie-api"
 */
const API_URL_OVERRIDE = "";

/** Apache's port in the XAMPP Control Panel (80 by default; some PCs use 8080). */
const API_PORT = 80;

const API_FOLDER = "/hunnypie-api";

function detectHost() {
  // In LAN mode this looks like "192.168.1.5:8081". In tunnel mode it's a web address, which can't reach XAMPP.
  const host = Constants.expoConfig?.hostUri?.split(":")[0];
  return host && /^(\d{1,3}\.){3}\d{1,3}$/.test(host) ? host : "localhost";
}

export const API_URL =
  API_URL_OVERRIDE || `http://${detectHost()}${API_PORT === 80 ? "" : `:${API_PORT}`}${API_FOLDER}`;
