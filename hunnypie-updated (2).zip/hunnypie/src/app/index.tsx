import { ActivityIndicator, View } from "react-native";
import { Redirect } from "expo-router";
import { useAuth } from "@/context/Auth";
import { useTheme } from "@/context/Theme";

/** Entry point: wait for the saved login to be checked, then go to the right side of the app. */
export default function Index() {
  const { user, loading } = useAuth();
  const { c } = useTheme();

  if (loading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: c.bg }}>
        <ActivityIndicator size="large" color={c.accent} />
      </View>
    );
  }
  return <Redirect href={user ? "/home" : "/login"} />;
}
