import { useRef, useState } from "react";
import { Text, View } from "react-native";
import { Link } from "expo-router";
import AuthInput, { TextInputHandle } from "@/components/AuthInput";
import AuthShell from "@/components/AuthShell";
import FormError from "@/components/FormError";
import PrimaryButton from "@/components/PrimaryButton";
import { EMAIL_RE, useAuth } from "@/context/Auth";
import { useTheme } from "@/context/Theme";

type Errors = { email?: string; password?: string; form?: string };

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { c } = useTheme();
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);
  const passwordRef = useRef<TextInputHandle>(null);

  const submit = async () => {
    if (busy) return;
    const next: Errors = {};
    if (!EMAIL_RE.test(email.trim())) next.email = "Enter a valid email address.";
    if (!password) next.password = "Enter your password.";
    if (next.email || next.password) return setErrors(next);

    setBusy(true);
    const result = await login(email, password);
    setBusy(false);
    // On success the (unauthenticated) layout redirects to /home automatically.
    setErrors(result.ok ? {} : { form: result.error });
  };

  return (
    <AuthShell
      title="Welcome back"
      subtitle="Log in to see what everyone is sharing."
      footer={
        <>
          <Text style={{ fontSize: 14, color: c.muted }}>New to Hunnypie? </Text>
          <Link href="/register" style={{ color: c.accent, fontWeight: "800", fontSize: 14 }}>
            Register
          </Link>
        </>
      }
    >
      <FormError message={errors.form} />

      <AuthInput
        label="Email"
        icon="mail-outline"
        placeholder="you@example.com"
        value={email}
        onChangeText={setEmail}
        error={errors.email}
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="email-address"
        textContentType="emailAddress"
        returnKeyType="next"
        onSubmitEditing={() => passwordRef.current?.focus()}
      />
      <AuthInput
        label="Password"
        icon="lock-closed-outline"
        placeholder="Your password"
        value={password}
        onChangeText={setPassword}
        error={errors.password}
        secure
        autoCapitalize="none"
        textContentType="password"
        returnKeyType="go"
        inputRef={passwordRef}
        onSubmitEditing={submit}
      />

      <View className="mt-2">
        <PrimaryButton title="Log in" onPress={submit} loading={busy} />
      </View>

    </AuthShell>
  );
}
