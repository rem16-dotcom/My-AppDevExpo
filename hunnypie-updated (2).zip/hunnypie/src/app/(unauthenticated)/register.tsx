import { useRef, useState } from "react";
import { Text, View } from "react-native";
import { Link } from "expo-router";
import AuthInput, { TextInputHandle } from "@/components/AuthInput";
import AuthShell from "@/components/AuthShell";
import FormError from "@/components/FormError";
import PrimaryButton from "@/components/PrimaryButton";
import { EMAIL_RE, useAuth } from "@/context/Auth";
import { useTheme } from "@/context/Theme";

type Errors = { name?: string; email?: string; password?: string; confirm?: string; form?: string };

export default function Register() {
  const { register } = useAuth();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const { c } = useTheme();
  const [errors, setErrors] = useState<Errors>({});
  const [busy, setBusy] = useState(false);
  const emailRef = useRef<TextInputHandle>(null);
  const passwordRef = useRef<TextInputHandle>(null);
  const confirmRef = useRef<TextInputHandle>(null);

  const submit = async () => {
    if (busy) return;
    const next: Errors = {};
    if (name.trim().length < 2) next.name = "Enter your name.";
    if (!EMAIL_RE.test(email.trim())) next.email = "Enter a valid email address.";
    if (password.length < 6) next.password = "Use at least 6 characters.";
    if (confirm !== password) next.confirm = "Passwords don't match.";
    if (Object.keys(next).length) return setErrors(next);

    setBusy(true);
    const result = await register({ name, email, password });
    setBusy(false);
    if (result.ok) return setErrors({}); // the (unauthenticated) layout redirects to /home
    const key = result.field === "name" || result.field === "email" || result.field === "password" ? result.field : "form";
    setErrors({ [key]: result.error });
  };

  return (
    <AuthShell
      title="Create your account"
      subtitle="Join Hunnypie and start sharing."
      footer={
        <>
          <Text style={{ fontSize: 14, color: c.muted }}>Already have an account? </Text>
          <Link href="/login" style={{ color: c.accent, fontWeight: "800", fontSize: 14 }}>
            Log in
          </Link>
        </>
      }
    >
      <FormError message={errors.form} />
      <AuthInput
        label="Name"
        icon="person-outline"
        placeholder="Your name"
        value={name}
        onChangeText={setName}
        error={errors.name}
        autoCapitalize="words"
        textContentType="name"
        returnKeyType="next"
        onSubmitEditing={() => emailRef.current?.focus()}
      />
      <AuthInput
        label="Email"
        icon="mail-outline"
        placeholder="you@example.com"
        value={email}
        onChangeText={setEmail}
        error={errors.email}
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType="email-address"
        textContentType="emailAddress"
        returnKeyType="next"
        inputRef={emailRef}
        onSubmitEditing={() => passwordRef.current?.focus()}
      />
      <AuthInput
        label="Password"
        icon="lock-closed-outline"
        placeholder="At least 6 characters"
        value={password}
        onChangeText={setPassword}
        error={errors.password}
        secure
        autoCapitalize="none"
        textContentType="newPassword"
        returnKeyType="next"
        inputRef={passwordRef}
        onSubmitEditing={() => confirmRef.current?.focus()}
      />
      <AuthInput
        label="Confirm password"
        icon="shield-checkmark-outline"
        placeholder="Type it again"
        value={confirm}
        onChangeText={setConfirm}
        error={errors.confirm}
        secure
        autoCapitalize="none"
        textContentType="newPassword"
        returnKeyType="go"
        inputRef={confirmRef}
        onSubmitEditing={submit}
      />

      <View className="mt-2">
        <PrimaryButton title="Create account" onPress={submit} loading={busy} />
      </View>
    </AuthShell>
  );
}
