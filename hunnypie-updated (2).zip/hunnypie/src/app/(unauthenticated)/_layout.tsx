import { Redirect, Stack } from "expo-router";
import { useAuth } from "@/context/Auth";

export default function UnauthenticatedLayout() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Redirect href="/home" />;
  return <Stack screenOptions={{ headerShown: false, animation: "fade" }} />;
}
