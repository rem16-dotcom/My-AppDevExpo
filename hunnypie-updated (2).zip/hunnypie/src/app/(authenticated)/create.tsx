import { useState } from "react";
import {
  KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, TextStyle, View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Image } from "expo-image";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import FormError from "@/components/FormError";
import { clampRatio } from "@/components/PinCard";
import { PickedImage, usePins } from "@/context/Pins";
import { useTheme } from "@/context/Theme";

const noOutline = { outlineStyle: "none" } as unknown as TextStyle;
const MAX_CAPTION = 200;

export default function Create() {
  const router = useRouter();
  const { c } = useTheme();
  const { addPin } = usePins();
  const [image, setImage] = useState<PickedImage | null>(null);
  const [caption, setCaption] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | undefined>();

  const close = () => (router.canGoBack() ? router.back() : router.replace("/home"));

  const pick = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], quality: 0.8 });
    if (result.canceled) return;
    const asset = result.assets[0];
    setImage({ uri: asset.uri, width: asset.width, height: asset.height, mimeType: asset.mimeType, fileName: asset.fileName });
    setError(undefined);
  };

  const post = async () => {
    if (!image || busy) return;
    setBusy(true);
    setError(undefined);
    const result = await addPin(image, caption);
    setBusy(false);
    if (result.ok) close();
    else setError(result.error);
  };

  const ready = !!image && !busy;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 12, paddingVertical: 10 }}>
        <Pressable onPress={close} hitSlop={10} accessibilityLabel="Close" style={{ padding: 6 }}>
          <Ionicons name="close" size={28} color={c.text} />
        </Pressable>
        <Text style={{ fontSize: 17, fontWeight: "800", color: c.text }}>Create pin</Text>
        <Pressable
          onPress={post}
          disabled={!ready}
          style={{ borderRadius: 22, backgroundColor: ready ? c.accent : c.surface2, paddingHorizontal: 20, paddingVertical: 9 }}
        >
          <Text style={{ fontSize: 15, fontWeight: "800", color: ready ? c.onAccent : c.muted }}>
            {busy ? "Posting..." : "Post"}
          </Text>
        </Pressable>
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
          <FormError message={error} />

          {image ? (
            <View style={{ overflow: "hidden", borderRadius: 24 }}>
              <Image
                source={{ uri: image.uri }}
                style={{ width: "100%", aspectRatio: clampRatio(image.width / Math.max(1, image.height)), backgroundColor: c.surface }}
                contentFit="cover"
              />
              <Pressable
                onPress={pick}
                style={{
                  position: "absolute", right: 12, bottom: 12, flexDirection: "row", alignItems: "center",
                  borderRadius: 20, backgroundColor: "rgba(0,0,0,0.6)", paddingHorizontal: 14, paddingVertical: 8,
                }}
              >
                <Ionicons name="swap-horizontal" size={16} color="#fff" />
                <Text style={{ marginLeft: 6, fontSize: 13, fontWeight: "700", color: "#fff" }}>Change</Text>
              </Pressable>
            </View>
          ) : (
            <Pressable
              onPress={pick}
              style={{
                height: 300, alignItems: "center", justifyContent: "center", borderRadius: 24,
                borderWidth: 2, borderStyle: "dashed", borderColor: c.border, backgroundColor: c.surface,
              }}
            >
              <View style={{ height: 64, width: 64, alignItems: "center", justifyContent: "center", borderRadius: 32, backgroundColor: c.surface2 }}>
                <Ionicons name="image-outline" size={30} color={c.accent} />
              </View>
              <Text style={{ marginTop: 14, fontSize: 16, fontWeight: "700", color: c.text }}>Choose a photo</Text>
              <Text style={{ marginTop: 4, fontSize: 13, color: c.muted }}>Tap to open your gallery</Text>
            </Pressable>
          )}

          <Text style={{ marginTop: 22, marginBottom: 8, marginLeft: 4, fontSize: 13, fontWeight: "600", color: c.text }}>Caption</Text>
          <TextInput
            value={caption}
            onChangeText={setCaption}
            placeholder="Tell everyone about your pin. Add #hashtags to make topics."
            placeholderTextColor={c.placeholder}
            multiline
            maxLength={MAX_CAPTION}
            style={[noOutline, {
              minHeight: 100, borderRadius: 16, backgroundColor: c.surface, padding: 14,
              fontSize: 15, lineHeight: 21, color: c.text, textAlignVertical: "top",
            }]}
          />
          <Text style={{ marginTop: 6, marginRight: 4, textAlign: "right", fontSize: 12, color: c.muted }}>
            {caption.length}/{MAX_CAPTION}
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
