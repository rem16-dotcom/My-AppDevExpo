import { Redirect, Stack } from "expo-router";
import { useAuth } from "@/context/Auth";
import { PinsProvider } from "@/context/Pins";
import { useTheme } from "@/context/Theme";

export default function AuthenticatedLayout() {
  const { user, loading } = useAuth();
  const { c } = useTheme();
  if (loading) return null;
  if (!user) return <Redirect href="/login" />;

  return (
    <PinsProvider>
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: c.bg } }}>
        <Stack.Screen name="create" options={{ presentation: "modal", animation: "slide_from_bottom" }} />
      </Stack>
    </PinsProvider>
  );
}
