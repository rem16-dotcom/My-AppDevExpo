import { useState } from "react";
import { KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, Switch, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import AuthInput from "@/components/AuthInput";
import Avatar from "@/components/Avatar";
import FormError from "@/components/FormError";
import PinGrid from "@/components/PinGrid";
import { useAuth } from "@/context/Auth";
import { usePins } from "@/context/Pins";
import { useTheme } from "@/context/Theme";

type Row = { icon: keyof typeof Ionicons.glyphMap; label: string; value: string };

export default function Profile() {
  const { c, dark, toggle } = useTheme();
  const { user, logout, updateProfile } = useAuth();
  const { mine, saved } = usePins();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: "", username: "", location: "", bio: "" });
  const [error, setError] = useState<{ field?: string; message: string } | null>(null);
  const [saving, setSaving] = useState(false);

  if (!user) return null; // the (authenticated) layout redirects to /login

  const joined = new Date(user.joinedAt).toLocaleDateString(undefined, { month: "long", year: "numeric" });
  const rows: Row[] = [
    { icon: "mail-outline", label: "Email", value: user.email },
    { icon: "location-outline", label: "Location", value: user.location || "Not set" },
    { icon: "calendar-outline", label: "Joined", value: joined },
  ];

  const openEdit = () => {
    setForm({ name: user.name, username: user.username, location: user.location, bio: user.bio });
    setError(null);
    setEditing(true);
  };

  const save = async () => {
    if (saving) return;
    setSaving(true);
    const result = await updateProfile(form);
    setSaving(false);
    if (result.ok) setEditing(false);
    else setError({ field: result.field, message: result.error });
  };

  const fieldError = (field: string) => (error?.field === field ? error.message : undefined);

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 130 }}>
        {/* Cover */}
        <View style={{ height: 150, overflow: "hidden", backgroundColor: c.surface }}>
          <View style={{ position: "absolute", right: -40, top: -50, height: 190, width: 190, borderRadius: 95, backgroundColor: c.accent, opacity: 0.35 }} />
          <View style={{ position: "absolute", left: -50, top: 60, height: 150, width: 150, borderRadius: 75, backgroundColor: c.accent, opacity: 0.18 }} />
        </View>

        <View style={{ alignItems: "center", paddingHorizontal: 24 }}>
          <View style={{ marginTop: -56, borderRadius: 60, backgroundColor: c.bg, padding: 5 }}>
            <Avatar uri={user.avatarUrl} name={user.name} size={104} />
          </View>
          <Text style={{ marginTop: 12, fontSize: 26, fontWeight: "800", color: c.text }}>{user.name}</Text>
          <Text style={{ marginTop: 2, fontSize: 15, fontWeight: "600", color: c.accent }}>@{user.username}</Text>
          <Text style={{ marginTop: 12, textAlign: "center", fontSize: 15, lineHeight: 21, color: c.text }}>
            {user.bio || "No bio yet. Tell people a little about you."}
          </Text>

          <View style={{ marginTop: 16, flexDirection: "row" }}>
            <Text style={{ fontSize: 14, color: c.muted }}>
              <Text style={{ fontWeight: "800", color: c.text }}>{mine.length}</Text> pins
            </Text>
            <Text style={{ marginHorizontal: 10, color: c.muted }}>·</Text>
            <Text style={{ fontSize: 14, color: c.muted }}>
              <Text style={{ fontWeight: "800", color: c.text }}>{saved.length}</Text> saved
            </Text>
          </View>

          <Pressable
            onPress={openEdit}
            style={({ pressed }) => ({
              marginTop: 18, flexDirection: "row", alignItems: "center", borderRadius: 24,
              backgroundColor: c.accent, paddingHorizontal: 24, paddingVertical: 12, opacity: pressed ? 0.85 : 1,
            })}
          >
            <Ionicons name="create-outline" size={18} color={c.onAccent} />
            <Text style={{ marginLeft: 8, fontSize: 15, fontWeight: "800", color: c.onAccent }}>Edit Profile</Text>
          </Pressable>
        </View>

        {/* Personal details */}
        <View style={{ marginHorizontal: 16, marginTop: 26, borderRadius: 24, backgroundColor: c.surface, paddingHorizontal: 18, paddingVertical: 4 }}>
          {rows.map((row, i) => (
            <View
              key={row.label}
              style={{ flexDirection: "row", alignItems: "center", paddingVertical: 14, borderTopWidth: i > 0 ? 1 : 0, borderTopColor: c.border }}
            >
              <View style={{ height: 40, width: 40, alignItems: "center", justifyContent: "center", borderRadius: 20, backgroundColor: c.surface2 }}>
                <Ionicons name={row.icon} size={20} color={c.accent} />
              </View>
              <View style={{ marginLeft: 12, flex: 1 }}>
                <Text style={{ fontSize: 12, color: c.muted }}>{row.label}</Text>
                <Text style={{ marginTop: 2, fontSize: 15, fontWeight: "600", color: c.text }}>{row.value}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Dark mode + log out */}
        <View style={{ marginHorizontal: 16, marginTop: 12, flexDirection: "row", alignItems: "center", borderRadius: 24, backgroundColor: c.surface, paddingHorizontal: 18, paddingVertical: 12 }}>
          <View style={{ height: 40, width: 40, alignItems: "center", justifyContent: "center", borderRadius: 20, backgroundColor: c.surface2 }}>
            <Ionicons name={dark ? "moon" : "sunny"} size={20} color={c.accent} />
          </View>
          <Text style={{ marginLeft: 12, flex: 1, fontSize: 15, fontWeight: "600", color: c.text }}>Dark mode</Text>
          <Switch value={dark} onValueChange={toggle} trackColor={{ false: c.border, true: c.accent }} thumbColor="#fff" />
        </View>

        <Pressable
          onPress={logout}
          style={({ pressed }) => ({
            marginHorizontal: 16, marginTop: 12, flexDirection: "row", alignItems: "center", justifyContent: "center",
            borderRadius: 24, borderWidth: 1.5, borderColor: c.border, paddingVertical: 14, opacity: pressed ? 0.7 : 1,
          })}
        >
          <Ionicons name="log-out-outline" size={20} color={c.text} />
          <Text style={{ marginLeft: 8, fontSize: 15, fontWeight: "700", color: c.text }}>Log out</Text>
        </Pressable>

        {/* My pins */}
        <Text style={{ marginHorizontal: 16, marginTop: 28, marginBottom: 12, fontSize: 18, fontWeight: "800", color: c.text }}>
          Your pins
        </Text>
        {mine.length === 0 ? (
          <Text style={{ marginHorizontal: 16, fontSize: 14, lineHeight: 20, color: c.muted }}>
            Photos you upload with the + button will show up here.
          </Text>
        ) : (
          <PinGrid pins={mine} />
        )}
      </ScrollView>

      {/* Edit profile sheet */}
      <Modal visible={editing} animationType="slide" onRequestClose={() => setEditing(false)}>
        <SafeAreaView style={{ flex: 1, backgroundColor: c.bg }}>
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: c.border, paddingHorizontal: 16, paddingVertical: 12 }}>
            <Pressable onPress={() => setEditing(false)} hitSlop={10}>
              <Text style={{ fontSize: 15, fontWeight: "600", color: c.muted }}>Cancel</Text>
            </Pressable>
            <Text style={{ fontSize: 16, fontWeight: "800", color: c.text }}>Edit Profile</Text>
            <Pressable onPress={save} hitSlop={10}>
              <Text style={{ fontSize: 15, fontWeight: "800", color: c.accent }}>{saving ? "Saving..." : "Save"}</Text>
            </Pressable>
          </View>

          <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
            <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20 }}>
              <View style={{ alignItems: "center", marginBottom: 20 }}>
                <Avatar uri={user.avatarUrl} name={user.name} size={84} />
              </View>
              <FormError message={error && !error.field ? error.message : undefined} />
              <AuthInput
                label="Name"
                icon="person-outline"
                value={form.name}
                onChangeText={(name) => setForm((f) => ({ ...f, name }))}
                error={fieldError("name")}
                autoCapitalize="words"
              />
              <AuthInput
                label="Username"
                icon="at-outline"
                value={form.username}
                onChangeText={(username) => setForm((f) => ({ ...f, username }))}
                error={fieldError("username")}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <AuthInput
                label="Location"
                icon="location-outline"
                placeholder="City, Country"
                value={form.location}
                onChangeText={(location) => setForm((f) => ({ ...f, location }))}
                error={fieldError("location")}
              />
              <AuthInput
                label="Bio"
                icon="chatbubble-ellipses-outline"
                placeholder="Tell people a little about you"
                value={form.bio}
                onChangeText={(bio) => setForm((f) => ({ ...f, bio }))}
                error={fieldError("bio")}
                multiline
                maxLength={120}
                style={{ minHeight: 72, textAlignVertical: "top" }}
              />
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </View>
  );
}
