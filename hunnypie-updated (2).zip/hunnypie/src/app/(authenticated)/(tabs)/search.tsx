import { useMemo, useState } from "react";
import { Pressable, ScrollView, Text, TextInput, TextStyle, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import PinGrid from "@/components/PinGrid";
import PinsState from "@/components/PinsState";
import { usePins } from "@/context/Pins";
import { useTheme } from "@/context/Theme";

const noOutline = { outlineStyle: "none" } as unknown as TextStyle;

export default function Search() {
  const { c } = useTheme();
  const { pins, topics, loading, error, refresh } = usePins();
  const [query, setQuery] = useState("");

  const q = query.trim().toLowerCase().replace(/^#/, "");

  const results = useMemo(() => {
    if (!q) return [];
    return pins.filter(
      (p) =>
        p.caption.toLowerCase().includes(q) ||
        p.tags.some((t) => t.includes(q)) ||
        p.author.name.toLowerCase().includes(q) ||
        p.author.username.toLowerCase().includes(q)
    );
  }, [pins, q]);

  // When the box is empty: the pins other people save and comment on most.
  const popular = useMemo(
    () => [...pins].sort((a, b) => b.saveCount + b.commentCount - (a.saveCount + a.commentCount)),
    [pins]
  );

  return (
    <SafeAreaView edges={["top"]} style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ paddingHorizontal: 16, paddingTop: 8, paddingBottom: 12 }}>
        <View
          style={{
            flexDirection: "row", alignItems: "center", borderRadius: 28,
            backgroundColor: c.surface, paddingHorizontal: 16,
          }}
        >
          <Ionicons name="search" size={20} color={c.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search pins, #topics or people"
            placeholderTextColor={c.placeholder}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
            style={[noOutline, { flex: 1, marginLeft: 10, paddingVertical: 14, fontSize: 16, color: c.text }]}
          />
          {query ? (
            <Pressable onPress={() => setQuery("")} hitSlop={10}>
              <Ionicons name="close-circle" size={20} color={c.muted} />
            </Pressable>
          ) : null}
        </View>
      </View>

      <ScrollView
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 130 }}
      >
        {loading && pins.length === 0 ? (
          <PinsState loading />
        ) : error && pins.length === 0 ? (
          <PinsState error={error} onRetry={refresh} />
        ) : q ? (
          results.length === 0 ? (
            <PinsState icon="search-outline" title="No pins found" hint={`Nothing matches "${query.trim()}". Try another word or a #topic.`} />
          ) : (
            <>
              <Text style={{ paddingHorizontal: 16, paddingBottom: 10, fontSize: 13, color: c.muted }}>
                {results.length} {results.length === 1 ? "pin" : "pins"}
              </Text>
              <PinGrid pins={results} />
            </>
          )
        ) : (
          <>
            {topics.length > 1 ? (
              <View style={{ paddingHorizontal: 16, paddingBottom: 14 }}>
                <Text style={{ marginBottom: 10, fontSize: 18, fontWeight: "800", color: c.text }}>Topics</Text>
                <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
                  {topics.slice(1).map((topic) => (
                    <Pressable
                      key={topic}
                      onPress={() => setQuery(topic)}
                      style={{
                        marginRight: 8, marginBottom: 8, borderRadius: 20,
                        backgroundColor: c.surface2, paddingHorizontal: 16, paddingVertical: 9,
                      }}
                    >
                      <Text style={{ fontSize: 14, fontWeight: "700", color: c.text }}>#{topic}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            ) : null}
            <Text style={{ paddingHorizontal: 16, paddingBottom: 10, fontSize: 18, fontWeight: "800", color: c.text }}>
              Popular now
            </Text>
            <PinGrid pins={popular} />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
