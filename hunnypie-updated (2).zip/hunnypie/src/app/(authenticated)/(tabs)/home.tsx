import { useCallback, useMemo, useState } from "react";
import { RefreshControl, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Header from "@/components/Header";
import PinGrid from "@/components/PinGrid";
import PinsState from "@/components/PinsState";
import TopicTabs from "@/components/TopicTabs";
import { usePins } from "@/context/Pins";
import { useTheme } from "@/context/Theme";

export default function Home() {
  const { c } = useTheme();
  const { pins, topics, loading, error, refresh } = usePins();
  const [topic, setTopic] = useState("All");
  const [refreshing, setRefreshing] = useState(false);

  const activeTopic = topics.includes(topic) ? topic : "All";
  const shown = useMemo(
    () => (activeTopic === "All" ? pins : pins.filter((p) => p.tags.includes(activeTopic))),
    [pins, activeTopic]
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
  }, [refresh]);

  return (
    <SafeAreaView edges={["top"]} style={{ flex: 1, backgroundColor: c.bg }}>
      <Header />
      <TopicTabs topics={topics} active={activeTopic} onChange={setTopic} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: 14, paddingBottom: 130 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.accent} colors={[c.accent]} />
        }
      >
        {loading && pins.length === 0 ? (
          <PinsState loading />
        ) : error && pins.length === 0 ? (
          <PinsState error={error} onRetry={onRefresh} />
        ) : shown.length === 0 ? (
          <PinsState title="No pins yet" hint="Tap + at the top to upload your first photo." />
        ) : (
          <PinGrid pins={shown} />
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
