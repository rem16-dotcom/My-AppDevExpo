import { useCallback, useState } from "react";
import { RefreshControl, ScrollView, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import PinGrid from "@/components/PinGrid";
import PinsState from "@/components/PinsState";
import { usePins } from "@/context/Pins";
import { useTheme } from "@/context/Theme";

export default function Saved() {
  const { c } = useTheme();
  const { saved, loading, error, refresh } = usePins();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refresh();
    setRefreshing(false);
  }, [refresh]);

  return (
    <SafeAreaView edges={["top"]} style={{ flex: 1, backgroundColor: c.bg }}>
      <View style={{ paddingHorizontal: 16, paddingTop: 8, paddingBottom: 14 }}>
        <Text style={{ fontSize: 30, fontWeight: "800", color: c.text, letterSpacing: -0.5 }}>Saved</Text>
        <Text style={{ marginTop: 2, fontSize: 14, color: c.muted }}>
          {saved.length} {saved.length === 1 ? "pin" : "pins"}
        </Text>
      </View>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 130 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={c.accent} colors={[c.accent]} />
        }
      >
        {loading && saved.length === 0 ? (
          <PinsState loading />
        ) : error && saved.length === 0 ? (
          <PinsState error={error} onRetry={onRefresh} />
        ) : saved.length === 0 ? (
          <PinsState
            icon="bookmark-outline"
            title="Nothing saved yet"
            hint={"Open a pin and tap Save, or use the ... menu on any pin. It will show up here."}
          />
        ) : (
          <PinGrid pins={saved} />
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
