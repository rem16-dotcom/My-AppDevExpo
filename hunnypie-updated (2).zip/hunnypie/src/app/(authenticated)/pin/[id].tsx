import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, TextInput, TextStyle, View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import Avatar from "@/components/Avatar";
import { clampRatio } from "@/components/PinCard";
import { useAuth } from "@/context/Auth";
import { usePins } from "@/context/Pins";
import { useTheme } from "@/context/Theme";
import { api, ApiError } from "@/lib/api";
import { timeAgo } from "@/lib/time";

type Comment = {
  id: string;
  text: string;
  createdAt: string;
  mine: boolean;
  author: { id: string; name: string; username: string; avatarUrl: string };
};

const noOutline = { outlineStyle: "none" } as unknown as TextStyle;

export default function PinDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { c } = useTheme();
  const { user, token } = useAuth();
  const { getPin, toggleSave, bumpComments } = usePins();
  const pin = getPin(id);

  const [comments, setComments] = useState<Comment[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);

  const goBack = () => (router.canGoBack() ? router.back() : router.replace("/home"));

  const loadComments = useCallback(async () => {
    try {
      const res = await api<{ comments: Comment[] }>(`comments.php?pin=${id}`, { token });
      setComments(res.comments);
      setLoadError(null);
    } catch (e) {
      setLoadError(e instanceof ApiError ? e.message : "Couldn't load comments.");
    }
  }, [id, token]);

  useEffect(() => {
    loadComments();
  }, [loadComments]);

  const send = async () => {
    const value = text.trim();
    if (!value || sending) return;
    setSending(true);
    setSendError(null);
    try {
      const res = await api<{ comment: Comment; commentCount: number }>("add_comment.php", {
        method: "POST",
        token,
        body: { pinId: id, text: value },
      });
      setComments((prev) => [...(prev ?? []), res.comment]);
      bumpComments(id, res.commentCount);
      setText("");
    } catch (e) {
      setSendError(e instanceof ApiError ? e.message : "Couldn't post your comment.");
    } finally {
      setSending(false);
    }
  };

  const remove = async (commentId: string) => {
    try {
      const res = await api<{ commentCount: number }>("delete_comment.php", {
        method: "POST",
        token,
        body: { id: commentId },
      });
      setComments((prev) => (prev ?? []).filter((x) => x.id !== commentId));
      bumpComments(id, res.commentCount);
    } catch {
      // leave it in place if the server said no
    }
  };

  if (!pin) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: c.bg, padding: 32 }}>
        <Ionicons name="image-outline" size={48} color={c.muted} />
        <Text style={{ marginTop: 12, fontSize: 17, fontWeight: "700", color: c.text }}>This pin isn't available</Text>
        <Pressable onPress={goBack} style={{ marginTop: 18, borderRadius: 24, backgroundColor: c.accent, paddingHorizontal: 26, paddingVertical: 12 }}>
          <Text style={{ fontSize: 15, fontWeight: "800", color: c.onAccent }}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: c.bg }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 24 }}>
          {/* Photo */}
          <View style={{ marginTop: insets.top + 4, marginHorizontal: 8, overflow: "hidden", borderRadius: 28 }}>
            <Image
              source={{ uri: pin.imageUrl }}
              style={{ width: "100%", aspectRatio: clampRatio(pin.ratio), backgroundColor: c.surface }}
              contentFit="cover"
              transition={250}
            />
            <Pressable
              onPress={goBack}
              hitSlop={8}
              accessibilityLabel="Back"
              style={{
                position: "absolute", left: 12, top: 12, height: 40, width: 40, alignItems: "center",
                justifyContent: "center", borderRadius: 20, backgroundColor: "rgba(0,0,0,0.5)",
              }}
            >
              <Ionicons name="arrow-back" size={22} color="#fff" />
            </Pressable>
          </View>

          {/* Actions */}
          <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingTop: 16 }}>
            <Ionicons name="chatbubble-outline" size={24} color={c.text} />
            <Text style={{ marginLeft: 6, fontSize: 15, fontWeight: "700", color: c.text }}>{pin.commentCount}</Text>
            <Text style={{ marginLeft: 16, fontSize: 14, color: c.muted }}>
              {pin.saveCount} {pin.saveCount === 1 ? "save" : "saves"}
            </Text>
            <View style={{ flex: 1 }} />
            <Pressable
              onPress={() => toggleSave(pin.id)}
              style={({ pressed }) => ({
                flexDirection: "row", alignItems: "center", borderRadius: 24, paddingHorizontal: 22, paddingVertical: 12,
                backgroundColor: pin.saved ? c.surface2 : c.accent, opacity: pressed ? 0.85 : 1,
              })}
            >
              <Ionicons name={pin.saved ? "bookmark" : "bookmark-outline"} size={18} color={pin.saved ? c.text : c.onAccent} />
              <Text style={{ marginLeft: 8, fontSize: 15, fontWeight: "800", color: pin.saved ? c.text : c.onAccent }}>
                {pin.saved ? "Saved" : "Save"}
              </Text>
            </Pressable>
          </View>

          {/* Author + caption */}
          <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingTop: 18 }}>
            <Avatar uri={pin.author.avatarUrl} name={pin.author.name} size={44} />
            <View style={{ marginLeft: 12, flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: "800", color: c.text }}>{pin.author.name}</Text>
              <Text style={{ fontSize: 13, color: c.muted }}>@{pin.author.username} · {timeAgo(pin.createdAt)}</Text>
            </View>
          </View>
          {pin.caption ? (
            <Text style={{ paddingHorizontal: 16, paddingTop: 14, fontSize: 17, lineHeight: 24, fontWeight: "600", color: c.text }}>
              {pin.caption}
            </Text>
          ) : null}

          {/* Comments */}
          <Text style={{ paddingHorizontal: 16, paddingTop: 26, paddingBottom: 6, fontSize: 18, fontWeight: "800", color: c.text }}>
            Comments
          </Text>
          {comments === null && !loadError ? (
            <ActivityIndicator color={c.accent} style={{ marginTop: 16 }} />
          ) : loadError ? (
            <Pressable onPress={loadComments} style={{ paddingHorizontal: 16, paddingVertical: 10 }}>
              <Text style={{ fontSize: 14, color: c.danger }}>{loadError} Tap to retry.</Text>
            </Pressable>
          ) : comments && comments.length === 0 ? (
            <Text style={{ paddingHorizontal: 16, paddingTop: 6, fontSize: 14, color: c.muted }}>
              No comments yet. Be the first!
            </Text>
          ) : (
            comments?.map((cm) => (
              <View key={cm.id} style={{ flexDirection: "row", alignItems: "flex-start", paddingHorizontal: 16, paddingVertical: 10 }}>
                <Avatar uri={cm.author.avatarUrl} name={cm.author.name} size={36} />
                <View style={{ marginLeft: 12, flex: 1 }}>
                  <Text style={{ fontSize: 13, color: c.muted }}>
                    <Text style={{ fontWeight: "800", color: c.text }}>{cm.author.name}</Text>  {timeAgo(cm.createdAt)}
                  </Text>
                  <Text style={{ marginTop: 2, fontSize: 15, lineHeight: 21, color: c.text }}>{cm.text}</Text>
                </View>
                {cm.mine ? (
                  <Pressable onPress={() => remove(cm.id)} hitSlop={10} accessibilityLabel="Delete comment" style={{ marginLeft: 8, paddingTop: 2 }}>
                    <Ionicons name="trash-outline" size={18} color={c.muted} />
                  </Pressable>
                ) : null}
              </View>
            ))
          )}
        </ScrollView>

        {/* Comment box */}
        <View style={{ borderTopWidth: 1, borderTopColor: c.border, backgroundColor: c.bg, paddingHorizontal: 12, paddingTop: 10, paddingBottom: insets.bottom + 10 }}>
          {sendError ? <Text style={{ marginBottom: 6, marginLeft: 6, fontSize: 12, color: c.danger }}>{sendError}</Text> : null}
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            {user ? <Avatar uri={user.avatarUrl} name={user.name} size={36} /> : null}
            <TextInput
              value={text}
              onChangeText={setText}
              placeholder="Add a comment"
              placeholderTextColor={c.placeholder}
              maxLength={300}
              returnKeyType="send"
              onSubmitEditing={send}
              style={[noOutline, { flex: 1, marginLeft: 10, borderRadius: 22, backgroundColor: c.surface, paddingHorizontal: 16, paddingVertical: 11, fontSize: 15, color: c.text }]}
            />
            <Pressable
              onPress={send}
              disabled={!text.trim() || sending}
              accessibilityLabel="Post comment"
              style={{
                marginLeft: 8, height: 42, width: 42, alignItems: "center", justifyContent: "center",
                borderRadius: 21, backgroundColor: text.trim() ? c.accent : c.surface2,
              }}
            >
              {sending ? <ActivityIndicator color={c.onAccent} /> : <Ionicons name="arrow-up" size={22} color={text.trim() ? c.onAccent : c.muted} />}
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
