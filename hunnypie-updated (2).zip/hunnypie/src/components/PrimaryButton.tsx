import { ActivityIndicator, Pressable, Text } from "react-native";
import { useTheme } from "@/context/Theme";

type Props = { title: string; onPress: () => void; loading?: boolean };

export default function PrimaryButton({ title, onPress, loading }: Props) {
  const { c } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      disabled={loading}
      style={({ pressed }) => ({
        alignItems: "center",
        borderRadius: 16,
        backgroundColor: c.accent,
        paddingVertical: 16,
        opacity: loading ? 0.7 : pressed ? 0.85 : 1,
      })}
    >
      {loading ? (
        <ActivityIndicator color={c.onAccent} />
      ) : (
        <Text style={{ fontSize: 16, fontWeight: "800", color: c.onAccent }}>{title}</Text>
      )}
    </Pressable>
  );
}
