import { useState } from "react";
import { Text, View } from "react-native";
import { Image } from "expo-image";
import { useTheme } from "@/context/Theme";

type Props = { uri?: string; name: string; size?: number };

/** Profile picture with an initial fallback (offline / broken link). */
export default function Avatar({ uri, name, size = 40 }: Props) {
  const { c } = useTheme();
  const [failed, setFailed] = useState(false);
  const dim = { width: size, height: size, borderRadius: size / 2 };

  if (!uri || failed) {
    return (
      <View style={[dim, { alignItems: "center", justifyContent: "center", backgroundColor: c.surface2 }]}>
        <Text style={{ fontSize: size * 0.42, fontWeight: "800", color: c.accent }}>
          {name.trim().charAt(0).toUpperCase() || "?"}
        </Text>
      </View>
    );
  }

  return (
    <Image
      source={{ uri }}
      style={[dim, { backgroundColor: c.surface2 }]}
      contentFit="cover"
      onError={() => setFailed(true)}
    />
  );
}
