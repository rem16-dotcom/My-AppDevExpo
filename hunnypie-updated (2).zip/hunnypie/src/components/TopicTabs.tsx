import { Pressable, ScrollView, Text, View } from "react-native";
import { useTheme } from "@/context/Theme";

type Props = { topics: string[]; active: string; onChange: (topic: string) => void };

/** "All  Birthday  Pink ..." with an underline on the active one, like Pinterest's top tabs. */
export default function TopicTabs({ topics, active, onChange }: Props) {
  const { c } = useTheme();
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      style={{ flexGrow: 0 }}
      contentContainerStyle={{ paddingHorizontal: 16 }}
    >
      {topics.map((topic) => {
        const on = topic === active;
        return (
          <Pressable key={topic} onPress={() => onChange(topic)} style={{ marginRight: 24, paddingVertical: 4 }}>
            <Text
              style={{
                fontSize: 18,
                fontWeight: on ? "800" : "600",
                color: on ? c.text : c.muted,
                textTransform: "capitalize",
              }}
            >
              {topic}
            </Text>
            <View style={{ height: 3, borderRadius: 2, marginTop: 4, backgroundColor: on ? c.text : "transparent" }} />
          </Pressable>
        );
      })}
    </ScrollView>
  );
}
