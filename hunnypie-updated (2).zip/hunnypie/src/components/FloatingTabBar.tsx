import { ComponentProps, useEffect, useState } from "react";
import { Keyboard, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Tabs } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import Avatar from "@/components/Avatar";
import { useAuth } from "@/context/Auth";
import { useTheme } from "@/context/Theme";

type TabBarProps = Parameters<NonNullable<ComponentProps<typeof Tabs>["tabBar"]>>[0];

const META: Record<string, { label: string; icon: keyof typeof Ionicons.glyphMap; active: keyof typeof Ionicons.glyphMap }> = {
  home: { label: "Home", icon: "home-outline", active: "home" },
  search: { label: "Search", icon: "search-outline", active: "search" },
  saved: { label: "Saved", icon: "bookmark-outline", active: "bookmark" },
  profile: { label: "Profile", icon: "person-outline", active: "person" },
};

/** Floating rounded buttons at the bottom (Home / Search / Saved / Profile), like the Pinterest app. */
export default function FloatingTabBar({ state, emitter, navigateToTab }: TabBarProps) {
  const insets = useSafeAreaInsets();
  const { c, dark } = useTheme();
  const { user } = useAuth();
  const [keyboard, setKeyboard] = useState(false);

  useEffect(() => {
    const show = Keyboard.addListener("keyboardDidShow", () => setKeyboard(true));
    const hide = Keyboard.addListener("keyboardDidHide", () => setKeyboard(false));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  if (keyboard) return null;

  return (
    <View
      style={{
        position: "absolute", left: 0, right: 0, bottom: insets.bottom + 10,
        flexDirection: "row", justifyContent: "center", pointerEvents: "box-none",
      }}
    >
      {state.routes.map((route, index) => {
        const meta = META[route.name];
        if (!meta) return null;
        const focused = state.index === index;
        const color = focused ? c.accent : c.text;

        const onPress = () => {
          const event = emitter.emit({ type: "tabPress", target: route.key, canPreventDefault: true });
          if (!focused && !event.defaultPrevented) navigateToTab(route.key);
        };

        return (
          <Pressable
            key={route.key}
            onPress={onPress}
            accessibilityRole="button"
            accessibilityLabel={meta.label}
            style={{
              marginHorizontal: 4, minWidth: 74, alignItems: "center", borderRadius: 24,
              backgroundColor: c.navBg, paddingHorizontal: 14, paddingVertical: 11,
              shadowColor: "#000", shadowOpacity: dark ? 0 : 0.12, shadowRadius: 8,
              shadowOffset: { width: 0, height: 3 }, elevation: dark ? 0 : 3,
            }}
          >
            {route.name === "profile" && user ? (
              <View style={{ borderRadius: 14, borderWidth: focused ? 2 : 0, borderColor: c.accent }}>
                <Avatar uri={user.avatarUrl} name={user.name} size={26} />
              </View>
            ) : (
              <Ionicons name={focused ? meta.active : meta.icon} size={26} color={color} />
            )}
            <Text style={{ marginTop: 4, fontSize: 13, fontWeight: "700", color }}>{meta.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}
