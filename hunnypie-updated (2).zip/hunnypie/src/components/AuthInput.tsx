import { ComponentRef, Ref, useState } from "react";
import { Pressable, Text, TextInput, TextInputProps, TextStyle, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/Theme";

type Props = TextInputProps & {
  label: string;
  icon: keyof typeof Ionicons.glyphMap;
  error?: string;
  /** Password field with a show/hide toggle. */
  secure?: boolean;
  inputRef?: Ref<TextInputHandle>;
};

export type TextInputHandle = ComponentRef<typeof TextInput>;

const noOutline = { outlineStyle: "none" } as unknown as TextStyle;

export default function AuthInput({ label, icon, error, secure, inputRef, style, onFocus, onBlur, ...rest }: Props) {
  const { c } = useTheme();
  const [hidden, setHidden] = useState(!!secure);
  const [focused, setFocused] = useState(false);
  const borderColor = error ? c.danger : focused ? c.accent : c.border;

  return (
    <View style={{ marginBottom: 16 }}>
      <Text style={{ marginBottom: 6, marginLeft: 4, fontSize: 13, fontWeight: "600", color: c.text }}>{label}</Text>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          borderRadius: 16,
          borderWidth: 1.5,
          borderColor,
          backgroundColor: c.surface,
          paddingHorizontal: 16,
        }}
      >
        <Ionicons name={icon} size={19} color={focused ? c.accent : c.muted} />
        <TextInput
          {...rest}
          ref={inputRef}
          secureTextEntry={secure ? hidden : rest.secureTextEntry}
          placeholderTextColor={c.placeholder}
          onFocus={(e) => {
            setFocused(true);
            onFocus?.(e);
          }}
          onBlur={(e) => {
            setFocused(false);
            onBlur?.(e);
          }}
          style={[noOutline, { flex: 1, marginLeft: 12, paddingVertical: 14, fontSize: 15, color: c.text }, style]}
        />
        {secure ? (
          <Pressable onPress={() => setHidden((h) => !h)} hitSlop={10}>
            <Ionicons name={hidden ? "eye-outline" : "eye-off-outline"} size={20} color={c.muted} />
          </Pressable>
        ) : null}
      </View>
      {error ? <Text style={{ marginLeft: 4, marginTop: 4, fontSize: 12, color: c.danger }}>{error}</Text> : null}
    </View>
  );
}
