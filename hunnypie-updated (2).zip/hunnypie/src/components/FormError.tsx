import { Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/Theme";

export default function FormError({ message }: { message?: string }) {
  const { c } = useTheme();
  if (!message) return null;
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        marginBottom: 16,
        borderRadius: 12,
        backgroundColor: c.dangerBg,
        paddingHorizontal: 12,
        paddingVertical: 10,
      }}
    >
      <Ionicons name="alert-circle" size={18} color={c.danger} />
      <Text style={{ flex: 1, marginLeft: 8, fontSize: 13, color: c.danger }}>{message}</Text>
    </View>
  );
}
