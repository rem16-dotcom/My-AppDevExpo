import { ActivityIndicator, Pressable, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/Theme";

type Props = {
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  title?: string;
  hint?: string;
};

/** Spinner, server error with Retry, or an empty-state message. */
export default function PinsState({ loading, error, onRetry, icon = "images-outline", title, hint }: Props) {
  const { c } = useTheme();

  if (loading) {
    return (
      <View style={{ alignItems: "center", paddingTop: 80 }}>
        <ActivityIndicator size="large" color={c.accent} />
      </View>
    );
  }

  return (
    <View style={{ alignItems: "center", paddingHorizontal: 32, paddingTop: 72 }}>
      <Ionicons name={error ? "cloud-offline-outline" : icon} size={52} color={c.muted} />
      <Text style={{ marginTop: 14, textAlign: "center", fontSize: 17, fontWeight: "700", color: c.text }}>
        {error ? "Couldn't load pins" : title}
      </Text>
      <Text style={{ marginTop: 6, textAlign: "center", fontSize: 14, lineHeight: 20, color: c.muted }}>
        {error ?? hint}
      </Text>
      {error && onRetry ? (
        <Pressable
          onPress={onRetry}
          style={{ marginTop: 18, borderRadius: 24, backgroundColor: c.accent, paddingHorizontal: 26, paddingVertical: 12 }}
        >
          <Text style={{ fontSize: 15, fontWeight: "800", color: c.onAccent }}>Try again</Text>
        </Pressable>
      ) : null}
    </View>
  );
}
