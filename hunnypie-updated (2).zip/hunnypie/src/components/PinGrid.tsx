import { useMemo } from "react";
import { View } from "react-native";
import type { Pin } from "@/context/Pins";
import PinCard, { clampRatio } from "./PinCard";

/** Pinterest-style two-column masonry. Put it inside a ScrollView. */
export default function PinGrid({ pins }: { pins: Pin[] }) {
  const [left, right] = useMemo(() => {
    const cols: [Pin[], Pin[]] = [[], []];
    const heights = [0, 0];
    for (const pin of pins) {
      const i = heights[0] <= heights[1] ? 0 : 1;
      cols[i].push(pin);
      heights[i] += 1 / clampRatio(pin.ratio) + 0.22; // image height (relative to width) + caption row
    }
    return cols;
  }, [pins]);

  return (
    <View style={{ flexDirection: "row", paddingHorizontal: 8 }}>
      <View style={{ flex: 1, marginRight: 4 }}>
        {left.map((p) => (
          <PinCard key={p.id} pin={p} />
        ))}
      </View>
      <View style={{ flex: 1, marginLeft: 4 }}>
        {right.map((p) => (
          <PinCard key={p.id} pin={p} />
        ))}
      </View>
    </View>
  );
}
