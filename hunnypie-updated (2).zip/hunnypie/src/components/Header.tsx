import { Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/context/Theme";

/** Logo on the left; "+" (new pin) and the dark-mode toggle on the right. */
export default function Header() {
  const router = useRouter();
  const { c, dark, toggle } = useTheme();

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 16,
        paddingTop: 4,
        paddingBottom: 10,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <Ionicons name="heart" size={30} color={c.accent} />
        <Text style={{ marginLeft: 6, fontSize: 30, fontWeight: "800", color: c.text, letterSpacing: -1 }}>
          Hunnypie
        </Text>
      </View>

      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <Pressable onPress={() => router.push("/create")} hitSlop={8} accessibilityLabel="Create pin" style={{ padding: 6 }}>
          <Ionicons name="add" size={34} color={c.text} />
        </Pressable>
        <Pressable onPress={toggle} hitSlop={8} accessibilityLabel="Toggle dark mode" style={{ padding: 6, marginLeft: 6 }}>
          <Ionicons name={dark ? "sunny-outline" : "moon-outline"} size={26} color={c.text} />
        </Pressable>
      </View>
    </View>
  );
}
