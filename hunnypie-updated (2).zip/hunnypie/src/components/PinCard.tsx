import { useState } from "react";
import { Modal, Pressable, Text, View } from "react-native";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Pin, usePins } from "@/context/Pins";
import { useTheme } from "@/context/Theme";

/** Keep very tall / very wide photos from taking over the feed. */
export const clampRatio = (ratio: number) => Math.min(Math.max(ratio, 0.5), 1.5);

type MenuRow = { icon: keyof typeof Ionicons.glyphMap; label: string; danger?: boolean; onPress: () => void };

export default function PinCard({ pin }: { pin: Pin }) {
  const router = useRouter();
  const { c } = useTheme();
  const { toggleSave, hidePin, removePin } = usePins();
  const [menuOpen, setMenuOpen] = useState(false);

  const rows: MenuRow[] = [
    {
      icon: pin.saved ? "bookmark" : "bookmark-outline",
      label: pin.saved ? "Remove from Saved" : "Save",
      onPress: () => toggleSave(pin.id),
    },
    { icon: "eye-off-outline", label: "Hide pin", onPress: () => hidePin(pin.id) },
    ...(pin.mine
      ? [{ icon: "trash-outline" as const, label: "Delete pin", danger: true, onPress: () => void removePin(pin.id) }]
      : [{ icon: "flag-outline" as const, label: "Report pin", onPress: () => hidePin(pin.id) }]),
  ];

  return (
    <View style={{ marginBottom: 16 }}>
      <Pressable onPress={() => router.push(`/pin/${pin.id}`)}>
        <Image
          source={{ uri: pin.imageUrl }}
          style={{ width: "100%", aspectRatio: clampRatio(pin.ratio), borderRadius: 24, backgroundColor: c.surface }}
          contentFit="cover"
          transition={250}
        />
      </Pressable>

      <View style={{ flexDirection: "row", alignItems: "flex-start", paddingHorizontal: 6, paddingTop: 8 }}>
        <Text numberOfLines={2} style={{ flex: 1, fontSize: 13, fontWeight: "600", color: c.text }}>
          {pin.caption}
        </Text>
        <Pressable onPress={() => setMenuOpen(true)} hitSlop={10} style={{ marginLeft: 8 }}>
          <Ionicons name="ellipsis-horizontal" size={20} color={c.text} />
        </Pressable>
      </View>

      <Modal visible={menuOpen} transparent animationType="fade" onRequestClose={() => setMenuOpen(false)}>
        <Pressable
          onPress={() => setMenuOpen(false)}
          style={{ flex: 1, justifyContent: "flex-end", backgroundColor: c.overlay }}
        >
          <View
            style={{
              borderTopLeftRadius: 28, borderTopRightRadius: 28, backgroundColor: c.surface,
              paddingHorizontal: 20, paddingBottom: 32, paddingTop: 12,
            }}
          >
            <View style={{ alignSelf: "center", marginBottom: 12, height: 4, width: 40, borderRadius: 2, backgroundColor: c.border }} />
            {rows.map((row) => (
              <Pressable
                key={row.label}
                onPress={() => {
                  setMenuOpen(false);
                  row.onPress();
                }}
                style={{ flexDirection: "row", alignItems: "center", paddingVertical: 14 }}
              >
                <Ionicons name={row.icon} size={22} color={row.danger ? c.danger : c.text} />
                <Text style={{ marginLeft: 14, fontSize: 16, fontWeight: "600", color: row.danger ? c.danger : c.text }}>
                  {row.label}
                </Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}
