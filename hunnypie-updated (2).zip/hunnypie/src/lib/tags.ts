/** "Sunset walk #pink #Pink" -> ["pink"] */
export function extractTags(caption: string): string[] {
  const found = caption.match(/#\w+/g) ?? [];
  return Array.from(new Set(found.map((tag) => tag.slice(1).toLowerCase())));
}
