import { API_URL } from "@/constants/config";

export class ApiError extends Error {
  status: number;
  field?: string;
  constructor(message: string, status: number, field?: string) {
    super(message);
    this.status = status; // 0 = couldn't reach the server
    this.field = field;
  }
}

type Options = { method?: "GET" | "POST"; body?: unknown; form?: FormData; token?: string | null };

/** Calls a PHP endpoint (e.g. "login.php") and returns its JSON, or throws an ApiError. */
export async function api<T>(path: string, { method = "GET", body, form, token }: Options = {}): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), form ? 60000 : 10000); // uploads get longer

  let res: Response;
  try {
    res = await fetch(`${API_URL}/${path}`, {
      method,
      headers: {
        // For FormData the browser/phone sets the Content-Type (with the multipart boundary) itself.
        ...(form ? {} : { "Content-Type": "application/json" }),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: form ?? (body === undefined ? undefined : JSON.stringify(body)),
      signal: controller.signal,
    });
  } catch {
    throw new ApiError(
      "Can't reach the server. Check that XAMPP (Apache + MySQL) is running and your phone is on the same Wi-Fi.",
      0
    );
  } finally {
    clearTimeout(timer);
  }

  let data: { ok?: boolean; error?: string; field?: string | null } | null = null;
  try {
    data = await res.json();
  } catch {
    // not JSON (e.g. a PHP error page)
  }

  if (!res.ok || !data?.ok) {
    throw new ApiError(data?.error ?? `Server error (${res.status}).`, res.status, data?.field ?? undefined);
  }
  return data as T;
}
