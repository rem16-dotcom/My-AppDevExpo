import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Platform } from "react-native";
import { API_URL } from "@/constants/config";
import { useAuth } from "@/context/Auth";
import { api, ApiError } from "@/lib/api";
import { extractTags } from "@/lib/tags";

type ServerPin = {
  id: string;
  caption: string;
  imagePath: string;
  ratio: number; // width / height
  createdAt: string;
  author: { id: string; name: string; username: string; avatarUrl: string };
  commentCount: number;
  saveCount: number;
  saved: boolean;
  mine: boolean;
};

export type Pin = ServerPin & { imageUrl: string; tags: string[] };

export type PickedImage = {
  uri: string;
  width: number;
  height: number;
  mimeType?: string | null;
  fileName?: string | null;
};

type Result = { ok: true } | { ok: false; error: string };

type PinsValue = {
  /** Every pin except the ones you hid this session (newest first). */
  pins: Pin[];
  saved: Pin[];
  mine: Pin[];
  /** "All" followed by the most-used #hashtags. */
  topics: string[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  getPin: (id: string) => Pin | undefined;
  toggleSave: (id: string) => Promise<void>;
  addPin: (image: PickedImage, caption: string) => Promise<Result>;
  removePin: (id: string) => Promise<Result>;
  hidePin: (id: string) => void;
  bumpComments: (id: string, count: number) => void;
};

const PinsContext = createContext<PinsValue | null>(null);

const decorate = (p: ServerPin): Pin => ({
  ...p,
  imageUrl: `${API_URL}/${p.imagePath}`,
  tags: extractTags(p.caption),
});

const message = (e: unknown) => (e instanceof ApiError ? e.message : "Something went wrong. Please try again.");

export function PinsProvider({ children }: { children: ReactNode }) {
  const { token } = useAuth();
  const [all, setAll] = useState<Pin[]>([]);
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await api<{ pins: ServerPin[] }>("pins.php", { token });
      setAll(res.pins.map(decorate));
      setError(null);
    } catch (e) {
      setError(message(e));
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    setLoading(true);
    refresh();
  }, [refresh]);

  const toggleSave = useCallback(
    async (id: string) => {
      const flip = (p: Pin): Pin =>
        p.id === id ? { ...p, saved: !p.saved, saveCount: Math.max(0, p.saveCount + (p.saved ? -1 : 1)) } : p;
      setAll((prev) => prev.map(flip)); // update the screen right away
      try {
        const res = await api<{ saved: boolean; saveCount: number }>("toggle_save.php", {
          method: "POST",
          token,
          body: { pinId: id },
        });
        setAll((prev) => prev.map((p) => (p.id === id ? { ...p, saved: res.saved, saveCount: res.saveCount } : p)));
      } catch {
        setAll((prev) => prev.map(flip)); // undo
      }
    },
    [token]
  );

  const addPin = useCallback<PinsValue["addPin"]>(
    async (image, caption) => {
      try {
        const form = new FormData();
        form.append("caption", caption.trim());
        if (Platform.OS === "web") {
          const blob = await (await fetch(image.uri)).blob();
          (form as unknown as { append(n: string, v: Blob, f: string): void }).append("image", blob, "photo.jpg");
        } else {
          form.append("image", {
            uri: image.uri,
            name: image.fileName ?? "photo.jpg",
            type: image.mimeType ?? "image/jpeg",
          } as unknown as Blob);
        }
        const res = await api<{ pin: ServerPin }>("upload_pin.php", { method: "POST", form, token });
        setAll((prev) => [decorate(res.pin), ...prev]);
        return { ok: true };
      } catch (e) {
        return { ok: false, error: message(e) };
      }
    },
    [token]
  );

  const removePin = useCallback<PinsValue["removePin"]>(
    async (id) => {
      try {
        await api("delete_pin.php", { method: "POST", token, body: { id } });
        setAll((prev) => prev.filter((p) => p.id !== id));
        return { ok: true };
      } catch (e) {
        return { ok: false, error: message(e) };
      }
    },
    [token]
  );

  const hidePin = useCallback((id: string) => setHidden((prev) => new Set(prev).add(id)), []);

  const bumpComments = useCallback(
    (id: string, count: number) => setAll((prev) => prev.map((p) => (p.id === id ? { ...p, commentCount: count } : p))),
    []
  );

  const getPin = useCallback((id: string) => all.find((p) => p.id === id), [all]);

  const value = useMemo<PinsValue>(() => {
    const pins = all.filter((p) => !hidden.has(p.id));
    const counts = new Map<string, number>();
    for (const p of pins) for (const t of p.tags) counts.set(t, (counts.get(t) ?? 0) + 1);
    const tags = [...counts.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .slice(0, 8)
      .map(([t]) => t);
    return {
      pins,
      saved: pins.filter((p) => p.saved),
      mine: all.filter((p) => p.mine),
      topics: ["All", ...tags],
      loading,
      error,
      refresh,
      getPin,
      toggleSave,
      addPin,
      removePin,
      hidePin,
      bumpComments,
    };
  }, [all, hidden, loading, error, refresh, getPin, toggleSave, addPin, removePin, hidePin, bumpComments]);

  return <PinsContext.Provider value={value}>{children}</PinsContext.Provider>;
}

export function usePins() {
  const ctx = useContext(PinsContext);
  if (!ctx) throw new Error("usePins must be used inside PinsProvider");
  return ctx;
}
