import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { api, ApiError } from "@/lib/api";

/** Auth backed by the PHP/MySQL API in the hunnypie-api folder (XAMPP). */

export type User = {
  id: string;
  name: string;
  username: string;
  email: string;
  avatarUrl: string;
  bio: string;
  location: string;
  joinedAt: string; // ISO date
};

export type AuthResult = { ok: true } | { ok: false; error: string; field?: string };

type Session = { token: string; user: User };

type AuthValue = {
  user: User | null;
  /** Login token, used by other contexts to call the API. */
  token: string | null;
  /** True while the saved login is being checked at app start. */
  loading: boolean;
  login: (email: string, password: string) => Promise<AuthResult>;
  register: (input: { name: string; email: string; password: string }) => Promise<AuthResult>;
  logout: () => Promise<void>;
  updateProfile: (patch: Pick<User, "name" | "username" | "bio" | "location">) => Promise<AuthResult>;
};

export const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const TOKEN_KEY = "hunnypie.token";

const AuthContext = createContext<AuthValue | null>(null);

function failure(e: unknown): AuthResult {
  if (e instanceof ApiError) return { ok: false, error: e.message, field: e.field };
  return { ok: false, error: "Something went wrong. Please try again." };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Restore the saved login when the app starts.
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(TOKEN_KEY);
        if (!saved) return;
        const res = await api<{ user: User }>("me.php", { token: saved });
        if (alive) {
          setToken(saved);
          setUser(res.user);
        }
      } catch (e) {
        // Token expired or revoked: forget it. (If the server is just offline, keep it for next time.)
        if (e instanceof ApiError && e.status === 401) await AsyncStorage.removeItem(TOKEN_KEY);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const startSession = useCallback(async (session: Session) => {
    await AsyncStorage.setItem(TOKEN_KEY, session.token);
    setToken(session.token);
    setUser(session.user);
  }, []);

  const login = useCallback<AuthValue["login"]>(
    async (email, password) => {
      try {
        await startSession(await api<Session>("login.php", { method: "POST", body: { email, password } }));
        return { ok: true };
      } catch (e) {
        return failure(e);
      }
    },
    [startSession]
  );

  const register = useCallback<AuthValue["register"]>(
    async (input) => {
      try {
        await startSession(await api<Session>("register.php", { method: "POST", body: input }));
        return { ok: true };
      } catch (e) {
        return failure(e);
      }
    },
    [startSession]
  );

  const logout = useCallback(async () => {
    const old = token;
    setUser(null);
    setToken(null);
    await AsyncStorage.removeItem(TOKEN_KEY);
    if (old) api("logout.php", { method: "POST", token: old }).catch(() => {});
  }, [token]);

  const updateProfile = useCallback<AuthValue["updateProfile"]>(
    async (patch) => {
      try {
        const res = await api<{ user: User }>("update_profile.php", { method: "POST", body: patch, token });
        setUser(res.user);
        return { ok: true };
      } catch (e) {
        return failure(e);
      }
    },
    [token]
  );

  const value = useMemo<AuthValue>(
    () => ({ user, token, loading, login, register, logout, updateProfile }),
    [user, token, loading, login, register, logout, updateProfile]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
