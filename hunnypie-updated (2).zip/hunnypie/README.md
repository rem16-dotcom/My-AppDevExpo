# Hunnypie

Pinterest-style pink inspiration app. Expo SDK 58 + Expo Router + NativeWind v4.

## Run

    npm install
    npm start        # = expo start -c  (clears the Metro cache)

Scan the QR code with Expo Go. If your phone can't reach your PC, use `npm run tunnel`.

Needs a current Expo Go (SDK 58). Phone and PC on the same Wi-Fi.
